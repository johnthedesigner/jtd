import sys, numpy as np
X=np.load(sys.argv[1])  # 75x3xT (mm)
T=X.shape[2]
r=np.load(sys.argv[2],allow_pickle=True).item(); mn=r['mn']
def kabsch(ix):
    P=X[ix]                        # m x3 xT
    ref=P[:,:,0]-P[:,:,0].mean(0)
    Rs=np.zeros((T,3,3)); ts=np.zeros((T,3))
    for f in range(T):
        Q=P[:,:,f]; c=Q.mean(0); H=ref.T@(Q-c)
        U,s,Vt=np.linalg.svd(H); dd=np.sign(np.linalg.det(Vt.T@U.T))
        R=Vt.T@np.diag([1,1,dd])@U.T; Rs[f]=R; ts[f]=c
    return Rs,ts
def score(a,b,step=3):
    Ra,ta=kabsch(a); Rb,tb=kabsch(b)
    fr=range(0,T,step)
    A=np.vstack([np.hstack([Ra[f],-Rb[f]]) for f in fr]); y=np.concatenate([tb[f]-ta[f] for f in fr])
    sol,res,rk,sv=np.linalg.lstsq(A,y,rcond=None)
    ca,cb=sol[:3],sol[3:]
    pa=np.einsum('fij,j->fi',Ra,ca)+ta; pb=np.einsum('fij,j->fi',Rb,cb)+tb
    err=np.linalg.norm(pa-pb,axis=1)
    return (pa+pb)/2, err, sv[-1]/sv[0]
segs={'thx':[7,10,27],'pel':[45,46,47,48,49,50],'hUA':[28,29,30,31],'hFA':[37,38,39],'tUA':[11,12,13,14],'tFA':[16,17,18,19],
'hTh':[51,52,53,54],'hSh':[56,57,58,59],'tTh':[63,64,65],'tSh':[68,69,70,71],'hHnd':[42,43,0,1,2],'tFA2':[20,21,22]}
joints={'sh_hit':('thx','hUA'),'sh_toss':('thx','tUA'),'el_hit':('hUA','hFA'),'el_toss':('tUA','tFA'),
 'hip_hit':('pel','hTh'),'hip_toss':('pel','tTh'),'kn_hit':('hTh','hSh'),'kn_toss':('tTh','tSh'),'wr_hit':('hFA','hHnd')}
JC={}
for j,(a,b) in joints.items():
    c,err,cond=score(segs[a],segs[b]); JC[j]=c.T
    # nearest markers to the joint centre
    dist=np.linalg.norm(X-c.T[None],axis=1).mean(1); near=np.argsort(dist)[:3]
    print(f'{j:8s} mismatch median {np.median(err):5.1f} mm  p90 {np.percentile(err,90):5.1f}  conditioning {cond:.3f}  nearest markers {near.tolist()} at {np.round(dist[near]).astype(int).tolist()} mm')
np.save(sys.argv[3],JC,allow_pickle=True)
