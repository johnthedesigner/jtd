import sys, os, glob, json, numpy as np, scipy.io as sio
d,out,SV=sys.argv[1],sys.argv[2],int(sys.argv[3]); S=os.path.dirname(out); fps=180
bad={86,95,2,3,4,5,6,45,50,52,53}
keys=sorted(int(f.split('_')[-1][:-4]) for f in glob.glob(os.path.join(d,'Spatio-Temporal Serve Data','*.mat')))
clean=[k for k in keys if k not in bad]; si=clean.index(SV); sl=slice(si*301,(si+1)*301)
XA=np.load(os.path.join(S,'allclean.npy')); T=XA.shape[2]
JC=np.load(os.path.join(S,'jc.npy'),allow_pickle=True).item()
# extra functional joint: toss ankle (shank plate vs foot markers)
def kabsch(ix):
    P=XA[ix]; ref=P[:,:,0]-P[:,:,0].mean(0); Rs=np.zeros((T,3,3)); ts=np.zeros((T,3))
    for f in range(T):
        Q=P[:,:,f]; c=Q.mean(0); U,s,Vt=np.linalg.svd(ref.T@(Q-c)); dd=np.sign(np.linalg.det(Vt.T@U.T))
        Rs[f]=Vt.T@np.diag([1,1,dd])@U.T; ts[f]=c
    return Rs,ts
Ra,ta=kabsch([68,69,70,71]); Rb,tb=kabsch([72,73,74]); fr=range(0,T,3)
A=np.vstack([np.hstack([Ra[f],-Rb[f]]) for f in fr]); y=np.concatenate([tb[f]-ta[f] for f in fr])
sol=np.linalg.lstsq(A,y,rcond=None)[0]
pa=np.einsum('fij,j->fi',Ra,sol[:3])+ta; pb=np.einsum('fij,j->fi',Rb,sol[3:])+tb
print('toss ankle mismatch median',np.median(np.linalg.norm(pa-pb,axis=1)).round(1))
JC['an_toss']=((pa+pb)/2).T
X=XA[:,:,sl]; J={k:v[:,sl] for k,v in JC.items()}
M=lambda *ix: X[list(ix)].mean(0)
J['head']=M(3,4,5,6); J['neck']=M(7,10); J['wr_toss']=M(23,24); J['hand_hit']=M(42,43); J['hand_toss']=M(25,26)
J['an_hit']=M(60,61); J['toe_hit']=X[62]; J['toe_toss']=X[74]; J['pelvis']=(J['hip_hit']+J['hip_toss'])/2
land={'ij':X[7],'c7':X[10],'px':X[27],'asisR':X[45],'asisL':X[48],'psisR':X[49],'psisL':X[50],'headF':M(3,4),'headB':M(5,6)}
def ang(a,b,c):
    p=J[a]-J[b]; q=J[c]-J[b]; return np.degrees(np.arccos(np.clip((p*q).sum(0)/np.linalg.norm(p,axis=0)/np.linalg.norm(q,axis=0),-1,1)))
elb=ang('sh_hit','el_hit','wr_hit'); knee=ang('hip_toss','kn_toss','an_toss')
yaw=lambda v: np.degrees(np.arctan2(v[1],v[0]))
sep=(yaw(J['hip_toss']-J['hip_hit'])-yaw(J['sh_toss']-J['sh_hit'])+180)%360-180
for a,b in [('sh_hit','el_hit'),('el_hit','wr_hit'),('hip_toss','kn_toss'),('kn_toss','an_toss'),('kn_hit','an_hit')]:
    L=np.linalg.norm(J[a]-J[b],axis=0); print(a,b,int(L.mean()),round(L.std(),1))
mid=(X[1]+X[2])/2; B=X[0]; u=(mid-B)/np.linalg.norm(mid-B,axis=0); head=B+u*185
dv=np.linalg.norm(np.diff(head,axis=1),axis=0)*fps/1000; v=np.r_[dv[0],(dv[:-1]+dv[1:])/2,dv[-1]]
fc=int(np.argmax(v)); pk=int(np.argmax(dv))
js=list(range(pk+1,pk+5)); jimp=max(js,key=lambda j: dv[j-1]-dv[j]); cimp=jimp-0.5
ftoss=int(np.argmax(J['hand_toss'][2])); fdrop=int(np.argmin(head[2][ftoss:fc]))+ftoss
fload=int(np.argmin(knee[ftoss:fdrop+1]))+ftoss
ground=min(X[62,2,:60].min(),X[74,2,:60].min())
low=np.minimum(X[62,2],X[74,2])
air=np.where((low>ground+40)&(np.arange(301)>fload))[0]; ftake=int(air[0])
back=np.where((low<ground+40)&(np.arange(301)>ftake))[0]; fland=int(back[0]) if len(back) else None
w=X[2]-X[1]; w=w-u*(w*u).sum(0); w/=np.linalg.norm(w,axis=0); nrm=np.cross(w.T,u.T).T
fwd0=head[:,jimp]-head[:,jimp-2]; fwd0[2]=0; fwd0/=np.linalg.norm(fwd0)
face=np.degrees(np.arcsin((nrm*np.sign((nrm*fwd0[:,None]).sum(0)))[2]))
print('impact step drop',[round(dv[j],1) for j in range(pk-1,pk+5)],'contact',cimp,'face around',[round(face[f]) for f in range(int(cimp)-2,int(cimp)+3)])
print('events toss',ftoss,'load',fload,'drop',fdrop,'take',ftake,'contact',fc,'land',fland)
print('elbow@contact',elb[fc].round(),'knee min',knee[fload].round(),'sep range',sep.min().round(),sep.max().round(),'sep@load',sep[fload].round(),'sep@contact',sep[fc].round(),'elbow min',elb[200:fc].min().round())
fwd=fwd0.copy()#; fwd[2]=0; fwd/=np.linalg.norm(fwd)
names=['head','neck','sh_hit','el_hit','wr_hit','hand_hit','sh_toss','el_toss','wr_toss','hand_toss','pelvis','hip_hit','kn_hit','an_hit','toe_hit','hip_toss','kn_toss','an_toss','toe_toss']
r=lambda a: np.round(a).astype(int).T.reshape(-1).tolist()
data={'fps':fps,'n':301,'names':names,'joints':{k:r(J[k]) for k in names},'land':{k:r(v) for k,v in land.items()},
 'racket':[r(X[0]),r(X[1]),r(X[2])],'markers':np.round(X).astype(int).transpose(2,0,1).reshape(-1).tolist(),
 'speed':np.round(v,2).tolist(),'elbow':np.round(elb,1).tolist(),'knee':np.round(knee,1).tolist(),'sep':np.round(sep,1).tolist(),
 'headZ':np.round(head[2]).astype(int).tolist(),
 'events':{'toss':ftoss,'load':fload,'takeoff':ftake,'land':fland,'drop':fdrop,'contact':cimp,'peak':fc},'face':np.round(face,1).tolist(),'serve':SV,
 'fwd':np.round(fwd,4).tolist(),'ground':float(ground),'start':[float(J['pelvis'][0,0]),float(J['pelvis'][1,0])],
 'toeToss0':[float(X[74,0,0]),float(X[74,1,0])]}
s=json.dumps(data,separators=(',',':')); open(out,'w').write(s); print('bytes',len(s))
