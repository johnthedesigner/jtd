import sys, os, glob, numpy as np, openpyxl
d=sys.argv[1]; S=sys.argv[2]; fps=180
bad={86,95,2,3,4,5,6,45,50,52,53}
keys=sorted(int(f.split('_')[-1][:-4]) for f in glob.glob(os.path.join(d,'Spatio-Temporal Serve Data','*.mat')))
clean=[k for k in keys if k not in bad]
XA=np.load(os.path.join(S,'allclean.npy')); JC=np.load(os.path.join(S,'jc.npy'),allow_pickle=True).item()
wb=openpyxl.load_workbook(os.path.join(d,'Data Labels.xlsx'),read_only=True); lab={}
for r in list(wb.active.iter_rows(values_only=True))[2:]:
    if r[0] is not None: lab[int(r[0])]=str(r[1]).strip()
def ang(p,q):  # angle between vectors (deg), rows
    return np.degrees(np.arccos(np.clip((p*q).sum(0)/np.linalg.norm(p,axis=0)/np.linalg.norm(q,axis=0),-1,1)))
rows=[]
for si,k in enumerate(clean):
    sl=slice(si*301,(si+1)*301); X=XA[:,:,sl]; J={a:b[:,sl] for a,b in JC.items()}
    an_h=(X[60]+X[61])/2; wr_h=J['wr_hit']; neck=(X[7]+X[10])/2; pel=(J['hip_hit']+J['hip_toss'])/2
    B=X[0]; m=(X[1]+X[2])/2; u=(m-B)/np.linalg.norm(m-B,axis=0); hc=B+u*185; tip=B+u*330
    dv=np.linalg.norm(np.diff(hc,axis=1),axis=0)*fps/1000; pk=int(np.argmax(dv))
    j=max(range(pk+1,pk+5),key=lambda j: dv[j-1]-dv[j]); ci=j-1   # last frame before the impact slowdown
    tipv=np.linalg.norm(np.diff(tip,axis=1),axis=0)*fps/1000
    # front (toss-side) knee: need toss ankle; use functional estimate if present else foot markers
    an_t=(X[72]+X[73])/2
    knee_t=ang(J['hip_toss']-J['kn_toss'],an_t-J['kn_toss'])
    toss_peak=int(np.argmax(X[25:27].mean(0)[2]))
    drop=int(np.argmin(hc[2,toss_peak:ci]))+toss_peak
    elbow=ang(J['sh_hit']-J['el_hit'],wr_h-J['el_hit'])
    # trunk inclination from vertical (pelvis -> neck)
    tv=neck-pel; trunk=np.degrees(np.arccos(tv[2]/np.linalg.norm(tv,axis=0)))
    # approximate shoulder external rotation (90/90 convention): forearm angle about the humerus, 0 = forearm pointing forward, 90 = up
    hum=J['el_hit']-J['sh_hit']; fa=wr_h-J['el_hit']
    lat=J['sh_toss']-J['sh_hit']; tup=neck-(X[27]); tfw=np.cross(lat.T,tup.T).T  # thorax forward-ish
    tfw=-tfw if (tfw[:,0]*(X[7]-X[10])[:,0]).sum()<0 else tfw
    def proj(v,ax): axn=ax/np.linalg.norm(ax,axis=0); return v-axn*(v*axn).sum(0)
    r0=proj(tfw,hum); r90=proj(tup,hum); fp=proj(fa,hum)
    r0/=np.linalg.norm(r0,axis=0); r90=r90-r0*(r90*r0).sum(0); r90/=np.linalg.norm(r90,axis=0)
    er=np.degrees(np.unwrap(np.arctan2((fp*r90).sum(0),(fp*r0).sum(0))))
    k0=int(np.argmin(knee_t[toss_peak:drop+1]))+toss_peak
    rows.append(dict(serve=k,out=lab.get(k,'?'),contact_h=hc[2,ci]/1000-0.06,head_v=dv[ci-1] if dv[ci-1]>dv[ci] else dv[ci],tip_v=tipv[pk],
        knee_flex=180-knee_t[k0],elbow_flex_imp=180-elbow[ci],trunk_trophy=trunk[k0],er_max=np.nanmax(er[toss_peak:ci]),er_drop=er[drop],
        drop_vs_pelvis=(hc[2,drop]-pel[2,drop])/1000,t_drop_imp=(ci-drop)/fps,t_load_imp=(ci-k0)/fps))
import statistics as st
def summ(key,fmt='{:.1f}'):
    v=[r[key] for r in rows]; return f"median {fmt.format(st.median(v))}  range {fmt.format(min(v))}–{fmt.format(max(v))}"
for key in ['contact_h','head_v','tip_v','knee_flex','elbow_flex_imp','trunk_trophy','er_drop','er_max','drop_vs_pelvis','t_drop_imp','t_load_imp']:
    print(f'{key:16s}', summ(key,'{:.2f}' if key in ('contact_h','drop_vs_pelvis','t_drop_imp','t_load_imp') else '{:.1f}'))
r57=[r for r in rows if r['serve']==57][0]; print('serve 57',{a:(round(b,2) if isinstance(b,float) else b) for a,b in r57.items()})
