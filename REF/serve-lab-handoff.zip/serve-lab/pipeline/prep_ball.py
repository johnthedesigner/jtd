"""Add the recorded landing spot (from Data Labels.xlsx) and the swing direction to the exported serve, ready for ball.py."""
import sys, os, json, openpyxl
raw, src, out, serve = sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4])
wb = openpyxl.load_workbook(os.path.join(raw, 'Data Labels.xlsx'), read_only=True)
xy = None
for r in list(wb.active.iter_rows(values_only=True))[2:]:
    if r[0] == serve: xy = [float(r[2]), float(r[3])]
assert xy, f'serve {serve} has no landing coordinates (it did not land in)'
D = json.load(open(src)); D['landXY'] = xy; D['fwd0'] = D['fwd']
json.dump(D, open(out, 'w'))
print('landing spot', xy)
