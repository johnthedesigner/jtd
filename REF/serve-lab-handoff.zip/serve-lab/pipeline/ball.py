import sys, json, numpy as np
src,out=sys.argv[1],sys.argv[2]
D=json.load(open(src)); fps=180; N=D['n']; g=9.81
J=lambda k: np.array(D['joints'][k],float).reshape(-1,3)/1000   # metres, data coords (z up)
R=[np.array(r,float).reshape(-1,3)/1000 for r in D['racket']]
def lerp(a,t): i=min(N-2,int(np.floor(t))); f=t-i; return a[i]+(a[i+1]-a[i])*f
CF=D['events']['contact']
B,M1,M2=lerp(R[0],CF),lerp(R[1],CF),lerp(R[2],CF); m=(M1+M2)/2; u=(m-B)/np.linalg.norm(m-B)
w=M2-M1; w-=u*w.dot(u); w/=np.linalg.norm(w); n=np.cross(w,u)
c=B+u*0.185
def headc(tt):
    b_=lerp(R[0],tt); m_=(lerp(R[1],tt)+lerp(R[2],tt))/2; uu=(m_-b_)/np.linalg.norm(m_-b_); return b_+uu*0.185
vr=(headc(CF-0.5)-headc(CF-1.5))*fps   # racket head centre velocity over the frame just before impact
fh=vr.copy(); fh[2]=0; fh/=np.linalg.norm(fh)
if n.dot(fh)<0: n=-n
CP=c+n*0.035   # ball centre sits one radius in front of the strings
# ---- toss: pick release frame where hand velocity best matches required launch velocity
H=J('hand_toss'); off=np.array([0,0,0.045])
best=None
for fr in range(max(1,D['events']['toss']-40),D['events']['toss']+6):
    T=(CF-fr)/fps; P=H[fr]+off
    v0=(CP-P+np.array([0,0,.5*g*T*T]))/T
    vh=(H[fr+1]-H[fr-1])/2*fps
    err=np.linalg.norm(v0-vh)
    if best is None or err<best[0]: best=(err,fr,v0,vh,P)
err,fr,v0,vh,P=best
apex=P[2]+v0[2]**2/(2*g)
print('release frame',fr,'launch',v0.round(2),'hand vel',vh.round(2),'mismatch m/s',round(err,2),'apex m',round(apex,2),'release height',round(P[2],2),'drop to contact',round(apex-CP[2],2))
# ---- court frame: orient so the horizontal path from contact to the recorded landing spot follows the racket's horizontal swing direction
gnd=(D['ground']-25)/1000
O=np.array([D['start'][0],D['start'][1],0])/1000; toe=np.array([*D['toeToss0'],0])/1000
X,Y=D['landXY']
def court(phi):
    base=np.array(D['fwd0']+[0]); ca,sa=np.cos(phi),np.sin(phi)
    F=np.array([base[0]*ca-base[1]*sa,base[0]*sa+base[1]*ca,0]); Rt=np.array([F[1],-F[0],0])
    dB=(toe-O).dot(F)+0.04; CM=O+F*dB-Rt*0.5
    L=CM+Rt*(-X)+F*(18.285-Y); L[2]=gnd+0.0335
    return F,Rt,CM,L
def miss(phi):
    F,Rt,CM,L=court(phi); d=L-CP; d[2]=0; d/=np.linalg.norm(d); return np.degrees(np.arctan2(np.cross(fh,d)[2],fh.dot(d)))
lo,hi=np.radians(-40),np.radians(40)
for _ in range(60):
    mid=(lo+hi)/2
    if np.sign(miss(lo))==np.sign(miss(mid)): lo=mid
    else: hi=mid
phi=(lo+hi)/2; F,Rt,CM,L=court(phi)
print('court rotated by',round(np.degrees(phi),1),'deg; residual',round(miss(phi),2))
# ---- outgoing flight with drag and modest topspin
rho,r,mb,Cd=1.21,0.0335,0.0577,0.55; A=np.pi*r*r
vrs=float(np.linalg.norm(vr)); s0=1.45*vrs
spin_rpm=1500.0
def fly(theta,keep=False,dt=1/1800):
    hd=L-CP; hd[2]=0; hd/=np.linalg.norm(hd); left=np.cross(np.array([0,0,1.]),hd)
    v=s0*(hd*np.cos(theta)+np.array([0,0,1.])*np.sin(theta)); p=CP.copy(); t=0; pts=[(0,p.copy())]
    om=spin_rpm*2*np.pi/60; axis=left   # topspin: axis x v points down
    while p[2]>gnd+r and t<2:
        sp=np.linalg.norm(v); S=r*om/sp; CL=1/(2+1/S)
        a=-0.5*rho*A*Cd*sp*v/mb + 0.5*rho*A*CL*sp*np.cross(axis,v)/mb*1 + np.array([0,0,-g])
        v=v+a*dt; p=p+v*dt; t+=dt
        if keep: pts.append((t,p.copy()))
    return p,v,t,pts
def rng(theta):
    p,_,_,_=fly(theta); return (p-CP)[:2].dot((L-CP)[:2]/np.linalg.norm((L-CP)[:2]))
target=np.linalg.norm((L-CP)[:2]); lo,hi=np.radians(-20),np.radians(15)
for _ in range(50):
    mid=(lo+hi)/2
    if rng(mid)<target: lo=mid
    else: hi=mid
th=(lo+hi)/2; p,v,tf,pts=fly(th,keep=True)
# net clearance
netd=11.885; best=None
for tt,pp in pts:
    dd=(pp-CM).dot(F)
    if best is None or abs(dd-netd)<abs(best[0]-netd): best=(dd,pp[2]-gnd,np.linalg.norm(pp-CP))
print('ball speed off racket',round(s0,1),'m/s =',round(s0*3.6),'km/h (racket',round(vrs,1),') launch angle',round(np.degrees(th),1),'flight',round(tf,3),'s','net clearance',round(best[1]-0.914-r,2),'m','landing speed',round(np.linalg.norm(v),1))
# bounce
vb=v.copy(); vb[2]=-0.75*v[2]; vb[:2]*=0.62; pb=p.copy(); pb[2]=gnd+r
bpts=[]; tb=0; dt=1/1800
while tb<0.48:
    sp=np.linalg.norm(vb); vb=vb+(-0.5*rho*A*Cd*sp*vb/mb+np.array([0,0,-g]))*dt; pb=pb+vb*dt; tb+=dt
    if pb[2]<gnd+r: pb[2]=gnd+r; vb[2]=-0.7*vb[2]
    bpts.append((tf+tb,pb.copy()))
# ---- assemble per-frame ball positions
landF=CF+tf*fps; endF=int(np.ceil(landF+0.48*fps))
traj=[]
allpts=pts+bpts
ti=np.array([a for a,_ in allpts]); pi=np.array([b for _,b in allpts])
for f in range(endF+1):
    if f<=fr: q=H[min(f,N-1)]+off
    elif f<=CF:
        T=(f-fr)/fps; q=P+v0*T+np.array([0,0,-.5*g*T*T])
    else:
        tt=(f-CF)/fps; k=np.searchsorted(ti,tt); k=min(max(k,1),len(ti)-1)
        a=(tt-ti[k-1])/(ti[k]-ti[k-1]); q=pi[k-1]+(pi[k]-pi[k-1])*a
    traj.append(q)
traj=np.array(traj)
# make the contact frame exact: insert analytic positions at contact for fractional playback (JS handles via sampled frames)
D['fwd']=[round(F[0],5),round(F[1],5)]
D['ball']={'pos':np.round(traj*1000).astype(int).reshape(-1).tolist(),'n':len(traj),'release':fr,'land':round(landF,2),
 'cp':(CP*1000).round().tolist(),'landPt':(L*1000).round().tolist(),'apex':round(apex,2),'speed':round(s0*3.6),'racket':round(vrs,1),
 'net':round(best[1]-0.914-r,2),'flight':round(tf,2),'launch':round(np.degrees(th),1),'spin':spin_rpm,'X':X,'Y':Y,'releaseH':round(P[2]-gnd,2)}
json.dump(D,open(out,'w'),separators=(',',':')); print('frames',len(traj),'land frame',round(landF,1))
