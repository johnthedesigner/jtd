"""Inline the viewer data into the page template: python build.py template.html serve57_viewer.json serve-lab.html"""
import sys
tpl, data, out = sys.argv[1:4]
open(out, 'w').write(open(tpl).read().replace('__DATA__', open(data).read()))
