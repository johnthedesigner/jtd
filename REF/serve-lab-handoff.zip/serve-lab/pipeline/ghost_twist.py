import sys, os, glob, json, numpy as np
from scipy.spatial.transform import Rotation as Rot
d,S=sys.argv[1],sys.argv[2]; fps=180
D=json.load(open(os.path.join(S,'serve57_ext.json')))
bad={86,95,2,3,4,5,6,45,50,52,53}
keys=sorted(int(f.split('_')[-1][:-4]) for f in glob.glob(os.path.join(d,'Spatio-Temporal Serve Data','*.mat')))
clean=[k for k in keys if k not in bad]; XA=np.load(os.path.join(S,'allclean.npy')); JC=np.load(os.path.join(S,'jc.npy'),allow_pickle=True).item()
def sl(k): i=clean.index(k); return slice(i*301,(i+1)*301)
# ---- ghost: serve 39
g=sl(39); X=XA[:,:,g]; J={a:b[:,g] for a,b in JC.items()}
M=lambda *ix: X[list(ix)].mean(0)
G={'head':M(3,4,5,6),'neck':M(7,10),'sh_hit':J['sh_hit'],'el_hit':J['el_hit'],'wr_hit':J['wr_hit'],'hand_hit':M(42,43),
   'sh_toss':J['sh_toss'],'el_toss':J['el_toss'],'wr_toss':M(23,24),'hand_toss':M(25,26),'pelvis':(J['hip_hit']+J['hip_toss'])/2,
   'hip_hit':J['hip_hit'],'kn_hit':J['kn_hit'],'an_hit':M(60,61),'toe_hit':X[62],'hip_toss':J['hip_toss'],'kn_toss':J['kn_toss'],'an_toss':M(72,73),'toe_toss':X[74]}
r=lambda a: np.round(a).astype(int).T.reshape(-1).tolist()
B=X[0]; m=(X[1]+X[2])/2; u=(m-B)/np.linalg.norm(m-B,axis=0); hc=B+u*185
dv=np.linalg.norm(np.diff(hc,axis=1),axis=0)*fps/1000; pk=int(np.argmax(dv)); j=max(range(pk+1,pk+5),key=lambda j: dv[j-1]-dv[j])
cp=(hc[:,j-1]+hc[:,j])/2
D['ghost']={'serve':39,'contact':j-0.5,'joints':{k:r(v) for k,v in G.items()},'racket':[r(X[0]),r(X[1]),r(X[2])],'cp':np.round(cp).tolist(),'ahead':0.57,'aheadMain':0.83}
# ---- forearm twist for serve 57: wrist styloid line, orthogonal to the forearm; extrapolated frames ease to the elbow-plane normal
X=XA[:,:,sl(57)]; N=D['n']; LAST=D['recLast']
Jn={k:np.array(v,float).reshape(-1,3) for k,v in D['joints'].items()}
def unit(v): return v/np.linalg.norm(v,axis=-1,keepdims=True)
TW={}
for s,(a,b) in {'hit':(40,41),'toss':(23,24)}.items():
    ax=unit(Jn['wr_'+s]-Jn['el_'+s])
    st=np.zeros((N,3)); raw=(X[b]-X[a]).T
    st[:LAST+1]=raw-ax[:LAST+1]*(raw*ax[:LAST+1]).sum(1,keepdims=True)
    pn=np.cross(Jn['sh_'+s]-Jn['el_'+s],Jn['wr_'+s]-Jn['el_'+s]); pn=pn-ax*(pn*ax).sum(1,keepdims=True)
    st=unit(np.where(np.linalg.norm(st,axis=1,keepdims=True)>1e-6,st,1)); pn=unit(pn)
    # signed angle from plane normal to styloid line at the last recorded frame
    def sang(v,w,axis): return np.arctan2((np.cross(v,w)*axis).sum(-1),(v*w).sum(-1))
    d0=sang(pn[LAST],st[LAST],ax[LAST])
    tt=(np.arange(LAST+1,N)-LAST)/fps; s_=1-(1+9*tt)*np.exp(-9*tt)
    for i,f in enumerate(range(LAST+1,N)):
        st[f]=Rot.from_rotvec(ax[f]*d0*(1-s_[i])).apply(pn[f])
    TW[s]=np.round(st*1000).astype(int).reshape(-1).tolist()
D['twist']=TW
json.dump(D,open(os.path.join(S,'serve57_v7.json'),'w'),separators=(',',':')); print('ok', len(json.dumps(D))//1024,'KB')
