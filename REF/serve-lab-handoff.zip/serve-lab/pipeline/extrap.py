import sys, json, numpy as np
from scipy.spatial.transform import Rotation as Rot
src,out=sys.argv[1],sys.argv[2]
D=json.load(open(src)); fps=180; L0=D['n']; LAST=L0-1; NT=D['ball']['n']
P={k:np.array(v,float).reshape(-1,3) for k,v in D['joints'].items()}
LM={k:np.array(v,float).reshape(-1,3) for k,v in D['land'].items()}
RK=[np.array(r,float).reshape(-1,3) for r in D['racket']]
A={**P,**{'L_'+k:v for k,v in LM.items()},**{'R%d'%i:RK[i] for i in range(3)}}
up=np.array([0,0,1.])
# ---- end pose: a ready position built from the player's own segment shapes and measured lengths
F=np.array([D['fwd'][0],D['fwd'][1],0.]); F/=np.linalg.norm(F); left=np.cross(up,F); Rt=-left
E0={k:v[:4].mean(0) for k,v in A.items()}
def L(a,b): return np.linalg.norm(A[a][:LAST+1]-A[b][:LAST+1],axis=1).mean()
def frame(lat,upv):
    x=lat/np.linalg.norm(lat); y=upv-x*upv.dot(x); y/=np.linalg.norm(y); return np.c_[x,y,np.cross(x,y)]
E={}
# feet: front foot stays where it landed, back foot steps up beside it, both pointing at the net
ankZ=np.median([A['an_toss'][:4,2].mean(),A['an_hit'][:4,2].mean()]); toeZ=np.median([A['toe_toss'][:4,2].mean(),A['toe_hit'][:4,2].mean()])
for s in ['toss','hit']:
    fl=L('an_'+s,'toe_'+s); fh=np.sqrt(max(fl**2-(ankZ-toeZ)**2,1))
    if s=='toss': toe=A['toe_toss'][LAST].copy(); toe[2]=toeZ; an=toe-F*fh; an[2]=ankZ
    else: an=E['an_toss']+Rt*430+F*20; an[2]=ankZ; toe=an+F*fh; toe[2]=toeZ
    E['an_'+s]=an; E['toe_'+s]=toe
# pelvis: own shape, turned to face the net, height set for a slight knee bend (about 155 degrees)
pk=['pelvis','hip_hit','hip_toss','L_asisR','L_asisL','L_psisR','L_psisL']
lat0=E0['hip_toss']-E0['hip_hit']; lat0[2]=0
yaw=np.arctan2(np.cross(lat0,left)[2],lat0.dot(left)); Rz=Rot.from_rotvec(up*yaw)
P0={k:Rz.apply(E0[k]-E0['pelvis']) for k in pk}
ctr=(E['an_toss']+E['an_hit'])/2+F*30
kneeA=np.radians(155); zs=[]
for s in ['toss','hit']:
    l1,l2=L('hip_'+s,'kn_'+s),L('kn_'+s,'an_'+s); d=np.sqrt(l1*l1+l2*l2-2*l1*l2*np.cos(kneeA))
    hxy=ctr+P0['hip_'+s]; h=np.linalg.norm((hxy-E['an_'+s])[:2]); zs.append(E['an_'+s][2]+np.sqrt(max(d*d-h*h,1))-P0['hip_'+s][2])
pz=np.mean(zs); pc=np.array([ctr[0],ctr[1],pz])
for k in pk: E[k]=pc+P0[k]
# chest: own shape, square to the net, upright with a slight forward lean
tk=['neck','sh_hit','sh_toss','L_ij','L_c7','L_px','head','L_headF','L_headB']
Mf=frame(E0['sh_toss']-E0['sh_hit'],E0['neck']-(E0['L_px']+(E0['L_c7']-E0['L_ij'])/2))   # thorax long axis, ISB style (T8 estimated from C7-IJ depth)
lean=np.radians(5); upt=np.cos(lean)*up+np.sin(lean)*F
Mt=frame(left,upt); Rt_=Mt@Mf.T
spine=np.median(np.linalg.norm(A['neck'][:LAST+1]-A['pelvis'][:LAST+1],axis=1))
neck=pc+upt*spine
for k in tk: E[k]=neck+Rt_@(E0[k]-E0['neck'])
# racket: held in front, head tilted up to about face height, face on edge, off hand on the throat
rk=['R0','R1','R2']
def rframe(B,M1,M2):
    u=(M1+M2)/2-B; u/=np.linalg.norm(u); w=M2-M1; w-=u*w.dot(u); w/=np.linalg.norm(w); return np.c_[w,u,np.cross(w,u)]
F0=rframe(A['R0'][LAST],A['R1'][LAST],A['R2'][LAST])
ut=np.cos(np.radians(62))*F+np.sin(np.radians(62))*up+left*0.12; ut/=np.linalg.norm(ut)
best=None
for sgn in [1,-1]:
    nt=sgn*left; nt=nt-ut*nt.dot(ut); nt/=np.linalg.norm(nt); wt=np.cross(ut,nt); Ft=np.c_[wt,ut,nt]
    ang=Rot.from_matrix(Ft@F0.T).magnitude()
    if best is None or ang<best[0]: best=(ang,Ft)
Rr=best[1]@F0.T
grip=pc+F*340+Rt*60+up*185
for k in rk: E[k]=grip+Rr@(A[k][LAST]-A['hand_hit'][LAST])
E['hand_hit']=grip
uu=best[1][:,1]; nn=best[1][:,2]
E['hand_toss']=E['R0']-uu*45+left*30
# arms: elbows down and slightly out, solved with the measured arm lengths
def ik2(root,tgt,pole,l1,l2):
    d=tgt-root; dist=np.clip(np.linalg.norm(d),abs(l1-l2)+1,l1+l2-1); dn=d/np.linalg.norm(d); tgt=root+dn*dist
    a=(l1*l1-l2*l2+dist*dist)/(2*dist); h=np.sqrt(max(l1*l1-a*a,0)); pv=pole-root; pv=pv-dn*pv.dot(dn); pn=pv/np.linalg.norm(pv)
    return root+dn*a+pn*h,tgt
for s,side in [('hit',Rt),('toss',left)]:
    sh=E['sh_'+s]; hd=E['hand_'+s]; l1,l2,l3=L('sh_'+s,'el_'+s),L('el_'+s,'wr_'+s),L('wr_'+s,'hand_'+s)
    eg=sh-up*300+F*120+side*120
    wr=hd+(eg-hd)/np.linalg.norm(eg-hd)*l3
    el,wr=ik2(sh,wr,eg,l1,l2); E['el_'+s]=el; E['wr_'+s]=wr
for s,side in [('hit',Rt),('toss',left)]:
    l1,l2=L('hip_'+s,'kn_'+s),L('kn_'+s,'an_'+s)
    pole=(E['hip_'+s]+E['an_'+s])/2+F*300+side*60
    E['kn_'+s],_=ik2(E['hip_'+s],E['an_'+s],pole,l1,l2)
print('ready pose: pelvis height',int(pc[2]),'racket head centre height',int((E['R0']+uu*185)[2]),'head height',int(E['head'][2]),'grip height',int(grip[2]))
t=np.arange(1,NT-L0+1)/fps
def spring(p0,v0,pe,lam):
    d=p0-pe; return pe+(d+(v0+lam*d)*t[:,None])*np.exp(-lam*t)[:,None]
vel=lambda k:(A[k][LAST]-A[k][LAST-2])/2*fps
# ---- rigid segments with rotational springs
def kab(Pt,Q):
    pc,qc=Pt.mean(0),Q.mean(0); H=(Pt-pc).T@(Q-qc); U,s,Vt=np.linalg.svd(H); d=np.sign(np.linalg.det(Vt.T@U.T)); return Vt.T@np.diag([1,1,d])@U.T
def rigid(keys,lam,grip=None):
    ref=np.array([A[k][0] for k in keys]); refc=ref.mean(0); ref0=ref-refc
    def R_at(pts): return Rot.from_matrix(kab(ref0,pts-pts.mean(0)))
    pts=lambda f: np.array([A[k][f] for k in keys])
    R1,R0=R_at(pts(LAST)),R_at(pts(LAST-2))
    Rend=R_at(np.array([E[k] for k in keys]))
    w0=(R1*R0.inv()).as_rotvec()/2*fps
    from scipy.spatial.transform import Slerp
    sl=Slerp([0,1],Rot.concatenate([R1,Rend]))
    s=1-(1+lam*t)*np.exp(-lam*t); h=t*np.exp(-lam*t)        # s: eased progress, h: carries the measured spin then fades
    Rt=[Rot.from_rotvec(w0*h[i])*sl([s[i]])[0] for i in range(len(t))]
    c0=pts(LAST).mean(0); cv=(pts(LAST).mean(0)-pts(LAST-2).mean(0))/2*fps; ce=np.array([E[k] for k in keys]).mean(0)
    C=spring(c0,cv,ce,lam)
    o_last=R1.inv().apply(pts(LAST)-c0); o_end=Rend.inv().apply(np.array([E[k] for k in keys])-ce)
    wgt=((1+lam*t)*np.exp(-lam*t))[:,None,None]
    O=o_end[None]+(o_last-o_end)[None]*wgt
    res={k:np.array([C[i]+Rt[i].apply(O[i,j]) for i in range(len(t))]) for j,k in enumerate(keys)}
    return res,Rt,C,R1,c0
X={}
pel,_,_,_,_=rigid(['pelvis','hip_hit','hip_toss','L_asisR','L_asisL','L_psisR','L_psisL'],9)
thx,_,_,_,_=rigid(['neck','sh_hit','sh_toss','L_ij','L_c7','L_px','head','L_headF','L_headB'],9)
X.update(pel); X.update(thx)
# ---- limbs: end effectors on springs, middle joints by two-bone IK
ln=lambda a,b: np.linalg.norm(A[a][LAST-20:LAST+1]-A[b][LAST-20:LAST+1],axis=1).mean()
def ik(root,tgt,pole,l1,l2):
    d=tgt-root; dist=np.linalg.norm(d); dist=np.clip(dist,abs(l1-l2)+1,l1+l2-1); dn=d/np.linalg.norm(d); tgt=root+dn*dist
    a=(l1*l1-l2*l2+dist*dist)/(2*dist); h=np.sqrt(max(l1*l1-a*a,0))
    pv=pole-root; pv=pv-dn*pv.dot(dn); pn=pv/(np.linalg.norm(pv)+1e-9)
    return root+dn*a+pn*h, tgt
gA=min(A['an_toss'][:,2].min(),A['an_hit'][:,2].min())+5; gT=min(A['toe_toss'][:,2].min(),A['toe_hit'][:,2].min())+5
for side in ['hit','toss']:
    lam=10
    an=spring(A['an_'+side][LAST],vel('an_'+side),E['an_'+side],lam)
    toe=spring(A['toe_'+side][LAST],vel('toe_'+side),E['toe_'+side],lam)
    kn=spring(A['kn_'+side][LAST],vel('kn_'+side),E['kn_'+side],lam)
    if side=='hit':   # swinging leg: lift the foot through the swing so it does not drag
        s=np.clip(t/0.3,0,1); bump=120*np.sin(np.pi*s); an[:,2]+=bump; toe[:,2]+=bump
    an[:,2]=np.maximum(an[:,2],gA); toe[:,2]=np.maximum(toe[:,2],gT)
    l1,l2,l3=ln('hip_'+side,'kn_'+side),ln('kn_'+side,'an_'+side),ln('an_'+side,'toe_'+side)
    K=[];AN=[];TO=[]
    for i in range(len(t)):
        k,a=ik(X['hip_'+side][i],an[i],kn[i],l1,l2); K.append(k);AN.append(a)
        d=toe[i]-a; TO.append(a+d/np.linalg.norm(d)*l3)
    X['kn_'+side]=np.array(K);X['an_'+side]=np.array(AN);X['toe_'+side]=np.array(TO)
for side in ['hit','toss']:
    lam=10
    wr=spring(A['wr_'+side][LAST],vel('wr_'+side),E['wr_'+side],lam)
    el=spring(A['el_'+side][LAST],vel('el_'+side),E['el_'+side],lam)
    hd=spring(A['hand_'+side][LAST],vel('hand_'+side),E['hand_'+side],lam)
    l1,l2,l3=ln('sh_'+side,'el_'+side),ln('el_'+side,'wr_'+side),ln('wr_'+side,'hand_'+side)
    EL=[];WR=[];HD=[]
    for i in range(len(t)):
        e,w=ik(X['sh_'+side][i],wr[i],el[i],l1,l2); EL.append(e);WR.append(w); d=hd[i]-w; HD.append(w+d/np.linalg.norm(d)*l3)
    X['el_'+side]=np.array(EL);X['wr_'+side]=np.array(WR);X['hand_'+side]=np.array(HD)
# ---- racket: rotational spring, held at the measured grip point in the hitting hand
rk,Rt,C,R1,c0=rigid(['R0','R1','R2'],10)
keys=['R0','R1','R2']; ref=np.array([A[k][0] for k in keys]); ref0=ref-ref.mean(0)
pts=np.array([A[k][LAST] for k in keys]); Ro=Rot.from_matrix(kab(ref0,pts-pts.mean(0)))
g=Ro.inv().apply(A['hand_hit'][LAST]-pts.mean(0))
for j,k in enumerate(keys):
    loc=Ro.inv().apply(A[k][LAST]-pts.mean(0))
    X[k]=np.array([X['hand_hit'][i]-Rt[i].apply(g)+Rt[i].apply(loc) for i in range(len(t))])
# blend the racket's grip point in from its spring path over the first frames to avoid a jump
# ---- checks
for a,b in [('hip_hit','kn_hit'),('kn_hit','an_hit'),('sh_hit','el_hit'),('el_hit','wr_hit')]:
    l=np.linalg.norm(X[a]-X[b],axis=1); print(a,b,'len',int(ln(a,b)),'extrap',int(l.min()),int(l.max()))
jump=lambda k: np.linalg.norm(X[k][0]-A[k][LAST])
print('first-step jumps mm',{k:int(jump(k)) for k in ['pelvis','hand_hit','an_hit','R1','head']})
# ---- write back
def cat(k,src): return np.vstack([src[k],X[k]])
for k in D['joints']: D['joints'][k]=np.round(cat(k,A)).astype(int).reshape(-1).tolist()
for k in D['land']: D['land'][k]=np.round(np.vstack([A['L_'+k],X['L_'+k]])).astype(int).reshape(-1).tolist()
D['racket']=[np.round(np.vstack([A['R%d'%i],X['R%d'%i]])).astype(int).reshape(-1).tolist() for i in range(3)]
# derived series over the extension
J={k:np.array(v,float).reshape(-1,3) for k,v in D['joints'].items()}
def ang(a,b,c):
    p=J[a]-J[b]; q=J[c]-J[b]; return np.degrees(np.arccos(np.clip((p*q).sum(1)/np.linalg.norm(p,axis=1)/np.linalg.norm(q,axis=1),-1,1)))
B=np.array(D['racket'][0],float).reshape(-1,3); M=(np.array(D['racket'][1],float).reshape(-1,3)+np.array(D['racket'][2],float).reshape(-1,3))/2
u=(M-B)/np.linalg.norm(M-B,axis=1)[:,None]; hc=B+u*185
sp=np.r_[0,np.linalg.norm(np.diff(hc,axis=0),axis=1)*fps/1000]; sp[0]=sp[1]
w=np.array(D['racket'][2],float).reshape(-1,3)-np.array(D['racket'][1],float).reshape(-1,3); w=w-u*(w*u).sum(1)[:,None]; w/=np.linalg.norm(w,axis=1)[:,None]
n=np.cross(w,u); Fh=np.r_[F[:2],0]; face=np.degrees(np.arcsin((n*np.sign((n@Fh))[:,None])[:,2]))
yawf=lambda v: np.degrees(np.arctan2(v[:,1],v[:,0]))
sep=(yawf(J['hip_toss']-J['hip_hit'])-yawf(J['sh_toss']-J['sh_hit'])+180)%360-180
D['speed']=D['speed']+np.round(sp[L0:],2).tolist()
D['elbow']=D['elbow']+np.round(ang('sh_hit','el_hit','wr_hit')[L0:],1).tolist()
D['knee']=D['knee']+np.round(ang('hip_toss','kn_toss','an_toss')[L0:],1).tolist()
D['sep']=D['sep']+np.round(sep[L0:],1).tolist()
D['face']=D['face']+np.round(face[L0:],1).tolist()
D['headZ']=D['headZ']+np.round(hc[L0:,2]).astype(int).tolist()
dist=np.max([np.linalg.norm(X[k]-E[k],axis=1) for k in ['pelvis','head','hand_hit','hand_toss','an_hit','wr_hit','R1']],axis=0)
rf=int(np.argmax(dist<30)) if (dist<30).any() else len(dist)-1
D['readyF']=L0+rf; print('ready at frame',L0+rf,'=',round((L0+rf-D['events']['contact'])/fps,2),'s after contact; max error at end',int(dist[-1]),'mm')
D['recLast']=LAST; D['n']=NT
json.dump(D,open(out,'w'),separators=(',',':')); print('frames',NT,'speed at handoff',D['speed'][LAST-1:LAST+3])
