#!/usr/bin/env bash
# Rebuilds every derived file from the University of Bath dataset.
# Usage: ./run_all.sh /path/to/raw_dir /path/to/out_dir
#   raw_dir holds "Spatio-Temporal Serve Data/" (the .mat files) and "Data Labels.xlsx", unzipped from the dataset.
set -euo pipefail
RAW="$1"; OUT="$2"; HERE="$(cd "$(dirname "$0")" && pwd)"; mkdir -p "$OUT"
py(){ python3 -I "$HERE/$1" "${@:2}"; }
py rigid.py "$RAW" "$OUT/rigid.npy"                                 # stacks the 31 clean serves (allclean.npy), rigid-body clusters
py score.py "$OUT/allclean.npy" "$OUT/rigid.npy" "$OUT/jc.npy"        # functional joint centres (SCoRE)
py export3.py "$RAW" "$OUT/serve57.json" 57                            # serve 57: joints, landmarks, racket, events, readout series
py prep_ball.py "$RAW" "$OUT/serve57.json" "$OUT/serve57_in.json" 57   # recorded landing spot
py ball.py "$OUT/serve57_in.json" "$OUT/serve57_ball.json"             # simulated toss and ball flight, court orientation
py extrap.py "$OUT/serve57_ball.json" "$OUT/serve57_ext.json"          # follow-through and ready position after the recording
py ghost_twist.py "$RAW" "$OUT"                                        # comparison serve 39 + forearm twist -> serve57_v7.json
cp "$OUT/serve57_v7.json" "$OUT/serve57_viewer.json"
py validate.py "$RAW" "$OUT"                                           # research comparison numbers (prints)
echo "done: $OUT/serve57_viewer.json"
