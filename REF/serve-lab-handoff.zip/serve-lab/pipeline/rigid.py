import sys, glob, os, scipy.io as sio, numpy as np
from scipy.cluster.hierarchy import linkage, fcluster
from scipy.spatial.distance import squareform
d=sys.argv[1]
bad={86,95,2,3,4,5,6,45,50,52,53}
fs=glob.glob(os.path.join(d,'Spatio-Temporal Serve Data','*.mat'))
A={int(f.split('_')[-1][:-4]):sio.loadmat(f)['Serves3D'] for f in fs}
X=np.concatenate([A[k] for k in sorted(A) if k not in bad],axis=2)  # 75x3xT
np.save(os.path.join(os.path.dirname(sys.argv[2]),'allclean.npy'),X)
print('frames',X.shape[2])
D=np.linalg.norm(X[:,None]-X[None],axis=2); sd=D.std(2); mn=D.mean(2)
np.save(sys.argv[2],{'sd':sd,'mn':mn})
Z=linkage(squareform(sd,checks=False),'average')
lab=fcluster(Z,6,'distance')
for c in sorted(set(lab)):
    ix=np.where(lab==c)[0]; print(c, ix.tolist())
