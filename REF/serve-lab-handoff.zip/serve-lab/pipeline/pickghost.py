import sys, os, glob, json, numpy as np, openpyxl
d=sys.argv[1]; S=sys.argv[2]; fps=180
D=json.load(open(os.path.join(S,'serve57_ext.json')))
F=np.array([D['fwd'][0],D['fwd'][1]]); F/=np.linalg.norm(F)
O=np.array(D['start']); toe=np.array(D['toeToss0']); dB=(toe-O)@F+40   # baseline offset along F (mm), as used by the viewer
bad={86,95,2,3,4,5,6,45,50,52,53}
keys=sorted(int(f.split('_')[-1][:-4]) for f in glob.glob(os.path.join(d,'Spatio-Temporal Serve Data','*.mat')))
clean=[k for k in keys if k not in bad]; XA=np.load(os.path.join(S,'allclean.npy'))
wb=openpyxl.load_workbook(os.path.join(d,'Data Labels.xlsx'),read_only=True); lab={}
for r in list(wb.active.iter_rows(values_only=True))[2:]:
    if r[0] is not None: lab[int(r[0])]=(str(r[1]).strip(),r[2],r[3])
res=[]
for si,k in enumerate(clean):
    X=XA[:,:,si*301:(si+1)*301]; B=X[0]; m=(X[1]+X[2])/2; u=(m-B)/np.linalg.norm(m-B,axis=0); hc=B+u*185
    dv=np.linalg.norm(np.diff(hc,axis=1),axis=0)*fps/1000; pk=int(np.argmax(dv)); j=max(range(pk+1,pk+5),key=lambda j: dv[j-1]-dv[j]); c=(hc[:,j-1]+hc[:,j])/2
    ahead=(c[:2]-O)@F-dB; side=(c[:2]-O)@np.array([F[1],-F[0]])
    res.append((k,lab.get(k,('?',))[0],round(ahead/1000,2),round(side/1000,2),round(c[2]/1000,2),round(dv[pk],1),lab.get(k,(0,None,None))[1:],j-0.5))
for r in sorted(res,key=lambda r:r[2]): print(r)
